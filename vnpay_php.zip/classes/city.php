




<?php 
	$filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/database.php');
	include_once  ($filepath.'/../helpers/format.php');
 ?>




<?php 

	class city
	{
		private $db;
		private $fm;

		public function __construct()
		{
			$this->db = new Database();
			$this->fm = new Format();
		}
		public function Show_City(){
			$query = "SELECT * FROM tbl_city";
			$result = $this->db->select($query);
			return $result;
		}
	}
 ?>